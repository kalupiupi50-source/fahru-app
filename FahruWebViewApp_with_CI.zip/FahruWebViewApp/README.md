# Fahru WebView App

A simple Android app (Kotlin) that wraps https://fahru.fun/ in a WebView with:
- Pull to refresh
- File upload picker
- External app handling for tel:, mailto:, WhatsApp, etc.
- Download manager integration
- Back navigation
- Adaptive launcher icon

## Build (Android Studio)
1. Open Android Studio > **Open** > select this folder.
2. Let Gradle sync, then **Build > Make Project**.
3. Run on a device (**Run**), or build APK via **Build > Build Bundle(s)/APK(s) > Build APK(s)**.
4. The debug APK will appear under `app/build/outputs/apk/debug/`.

## Notes
- Target SDK 35, min SDK 24.
- For Play Store, use a **release** build with your keystore.
