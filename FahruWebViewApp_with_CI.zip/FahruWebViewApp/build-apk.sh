#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

# Check Java and Gradle wrapper
java -version || true
chmod +x ./gradlew

# Build debug APK
./gradlew :app:assembleDebug

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
  echo "APK generated at: $APK_PATH"
else
  echo "Build finished but APK not found." >&2
  exit 1
fi
